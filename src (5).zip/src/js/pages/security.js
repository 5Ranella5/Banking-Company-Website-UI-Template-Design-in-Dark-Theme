import { initFaqs } from '../modules/functionFaqs.js';

export const initSecurityPage = () => {
  initFaqs();
};
