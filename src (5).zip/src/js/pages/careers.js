import { initFaqs } from '../modules/functionFaqs';

export const initCareersPage = async () => {
  initFaqs();
};
