export const openModal = (modal) => {
  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
};
